/* Mendaftarkan service worker (mode offline) dan meminta penyimpanan permanen */
if("serviceWorker" in navigator){try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist();}catch(e){}window.addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){});});}
/* Warna bilah status (atas layar) selalu sama dengan warna layar tepat di bawahnya: halaman, header, lembar/modal penuh.
   Di aplikasi Android (Capacitor) lewat plugin StatusBar; di browser lewat meta theme-color. */
(function(){
var cap=null;try{var c=window.Capacitor;if(c&&c.isNativePlatform&&c.isNativePlatform()){cap=(c.Plugins&&c.Plugins.StatusBar)||c.registerPlugin('StatusBar');}}catch(e){}
var run=function(f){try{Promise.resolve(f()).catch(function(){});}catch(e){}};
if(cap){run(function(){return cap.setOverlaysWebView({overlay:false});});run(function(){return cap.setStyle({style:(window.EJ&&window.EJ.resolved==='light')?'LIGHT':'DARK'});});}
var BASE=(window.EJ&&window.EJ.bgRGB||[9,13,24,1]).slice(),last='';
function parse(str){var m=String(str||'').match(/rgba?\(([^)]+)\)/);if(!m)return null;var a=m[1].split(/[ ,\/]+/).filter(Boolean).map(Number);return [a[0],a[1],a[2],a.length>3?a[3]:1];}
function over(top,bot){var a=top[3];return [top[0]*a+bot[0]*(1-a),top[1]*a+bot[1]*(1-a),top[2]*a+bot[2]*(1-a),1];}
function layerColor(el){var cs=getComputedStyle(el),bg=parse(cs.backgroundColor);
 if(cs.backgroundImage&&cs.backgroundImage!=='none'){var g=parse(cs.backgroundImage);if(g)bg=g;}
 return bg;}
function topColor(){
 var x=Math.round(innerWidth/2),el=document.elementFromPoint(x,3),stack=[];
 for(var n=el;n&&n.nodeType===1;n=n.parentElement){var c=layerColor(n);if(c&&c[3]>0){stack.push(c);if(c[3]>=1)break;}}
 var col=stack.length&&stack[stack.length-1][3]>=1?stack.pop():BASE.slice();
 while(stack.length)col=over(stack.pop(),col);
 return col;}
function hex(c){return '#'+c.slice(0,3).map(function(v){v=Math.max(0,Math.min(255,Math.round(v)));return (v<16?'0':'')+v.toString(16);}).join('');}
function sync(){try{var h=hex(topColor());if(h===last)return;last=h;
 var m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute('content',h);
 if(cap)run(function(){return cap.setBackgroundColor({color:h});});}catch(e){}}
var q=0;function queue(){if(q)return;q=requestAnimationFrame(function(){q=0;sync();});}
window.syncStatusBar=queue;
function onAp(){try{BASE=(window.EJ.bgRGB||BASE).slice();last='';if(cap)run(function(){return cap.setStyle({style:window.EJ.resolved==='light'?'LIGHT':'DARK'});});}catch(e){}queue();}
window.addEventListener('ej-appearance',onAp);
function start(){try{new MutationObserver(queue).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','data-tab','data-nv']});}catch(e){}
 window.addEventListener('resize',queue);window.addEventListener('orientationchange',queue);setInterval(sync,1500);queue();}
if(document.body)start();else document.addEventListener('DOMContentLoaded',start);
})();
/* Splash bawaan Android (sebelum aplikasi terbuka) ikut tema dan mode di dalam aplikasi, bukan mode HP.
   Juga menyimpan warna latar tema agar jendela aplikasi tidak hitam setelah splash. Hanya di aplikasi Android yang sudah memuat plugin EjTheme; di tempat lain tidak melakukan apa-apa. Berlaku pada peluncuran berikutnya. */
(function(){
var p=null;try{var c=window.Capacitor;if(c&&c.isNativePlatform&&c.isNativePlatform()){p=(c.Plugins&&c.Plugins.EjTheme)||c.registerPlugin('EjTheme');}}catch(e){}
if(!p)return;
var last='';
function push(){try{var E=window.EJ,th=E&&E.state&&E.state.theme;if(!th||!E.resolved)return;
 var id=(th==='custom'||!/^[a-z0-9]+$/.test(th))?'neutral':th,bg=/^#[0-9a-fA-F]{6}$/.test(E.bg||'')?E.bg:'',key=id+'_'+E.resolved,sig=key+'|'+bg;if(sig===last)return;last=sig;
 Promise.resolve(p.setSplash({key:key,bg:bg})).catch(function(){last='';});}catch(e){}}
window.addEventListener('ej-appearance',push);
setTimeout(push,1200);setTimeout(push,6000);
})();
/* Penanda halaman sudah digulir (html[data-sc="1"]): header transparan di posisi paling atas, solid setelah digulir (tanpa blur) */
(function(){var f=0,el=document.documentElement;function u(){f=0;var v=(window.pageYOffset||el.scrollTop||0)>6?'1':'0';if(el.getAttribute('data-sc')!==v){el.setAttribute('data-sc',v);try{if(window.syncStatusBar)window.syncStatusBar();}catch(e){}}}
window.addEventListener('scroll',function(){if(!f)f=requestAnimationFrame(u);},{passive:true});u();})();
/* Ukuran tetap: cegah cubit-zoom (iOS Safari mengabaikan user-scalable=no) */
try{["gesturestart","gesturechange","gesturechange"].forEach(function(t){document.addEventListener(t,function(e){e.preventDefault();},{passive:false});});}catch(e){}
