/* Halaman My Journal dan kartu trade */
"use strict";
function PosStrip({ n, pnl, pct, pips, cur }) {
    const cls = pnl > 0 ? 'positive' : pnl < 0 ? 'negative' : '';
    return React.createElement("div", { className: "pos-strip" },
        React.createElement("span", { className: "ps-n" }, n + ' posisi'),
        React.createElement("span", { className: cls }, (pnl >= 0 ? '+' : '') + money(pnl, cur)),
        React.createElement("span", { className: cls }, fmtPctS(pct)),
        React.createElement("span", { className: cls }, fmtPipsS(pips)));
}
/* Pembantu tampilan bertingkat (Tahun -> Bulan -> Minggu) */
function jSum(list) { return { pnl: list.reduce((x, t) => x + (t.status === 'closed' ? Number(t.pnl) || 0 : 0), 0), pips: list.reduce((x, t) => x + tradePips(t), 0) }; }
function jDay(t) { return wib(new Date(new Date(t.date).getTime() - 7 * 3600 * 1000)).day; }
function jCal(t) { return wib(new Date(t.date)).day; } /* tanggal kalender WIB: dipakai untuk kartu Tahun/Bulan agar sama dengan Advanced Statistics */
function jMonday(day) { const md = new Date(Date.UTC(Number(day.slice(0, 4)), Number(day.slice(5, 7)) - 1, Number(day.slice(8, 10)))); md.setUTCDate(md.getUTCDate() - ((md.getUTCDay() + 6) % 7)); return md; }
function jWeekLabel(md) { const en = new Date(md.getTime() + 6 * 86400000); const f = (d, y) => d.toLocaleDateString('en-GB', y ? { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' } : { day: 'numeric', month: 'short', timeZone: 'UTC' }); return `${f(md)} - ${f(en, true)}`; }
function jMonthLabel(mk) { return new Date(Date.UTC(Number(mk.slice(0, 4)), Number(mk.slice(5, 7)) - 1, 1)).toLocaleDateString('id-ID', { month: 'long', year: 'numeric', timeZone: 'UTC' }); }
function jGroup(list, fn) { const o = {}; list.forEach(t => { (o[fn(t)] || (o[fn(t)] = [])).push(t); }); return o; }
/* Halaman utama My Journal: Tahun -> Bulan (grafik 1H/1S/1D/1W) -> Minggu (tanpa grafik).
   Posisi hanya tampil untuk kandel yang diketuk (1D/1S/1H); ketuk kandel 1W = kartu semua minggu dalam bulan itu. */
function HierJournal({ autoOpen, kind, status, list: allList, account, startBal, expanded, setExpanded, onDelete, onClose, onEdit }) {
    const [open, setOpen] = useState({});
    const [sels, setSels] = useState({});
    const list = allList.filter(t => t.status === 'closed'); // posisi open tidak ikut di tampilan bertingkat
    const cur = account.currency;
    const TFN = { H1: '1H', SES: '1S', D1: '1D', W1: '1W' };
    const byY = list.length ? jGroup(list, t => jCal(t).slice(0, 4)) : {};
    const years = Object.keys(byY).sort().reverse();
    const lastMonth = list.length && list.map(t => jCal(t).slice(0, 7)).sort().pop();
    const isOpen = (key, def) => key in open ? open[key] : def;
    const tog = (key, def) => setOpen(o => ({ ...o, [key]: !(key in o ? o[key] : def) }));
    const tradeCard = t => React.createElement(TradeCard, { key: t.id, trade: t, startBal: acctCapAt(account, t.date), expanded: expanded === t.id, onToggle: () => setExpanded(expanded === t.id ? null : t.id), onDelete: () => onDelete(t.id), onClose: () => onClose(t), onEdit: () => onEdit(t) });
    if (status === 'open') { const O = allList.filter(t => t.status !== 'closed').sort((a, b) => new Date(b.date) - new Date(a.date)); return O.length ? React.createElement("div", { className: "gj" }, O.map(tradeCard)) : null; }
    if (!list.length)
        return allList.length ? React.createElement("div", { className: "empty-state" }, React.createElement("span", null, "Belum ada posisi closed. Posisi open ada di filter Open.")) : null;
    const strip = L => { const sm = jSum(L); return React.createElement(PosStrip, { n: L.length, pnl: sm.pnl, pct: pctChain(account, L), pips: sm.pips, cur: cur }); };
    const head = (key, title, L, op, def, main) => React.createElement("button", { className: "week-head" + (main ? " gj-main lv-y" : ""), onClick: () => tog(key, def) },
        React.createElement("div", null, React.createElement("strong", null, title)),
        React.createElement(ChevronDown, { size: 17, className: op ? 'rotate' : '' }),
        strip(L));
    const selBlock = (key, L) => {
        const sel = sels[key];
        if (!sel || !sel.c)
            return null;
        if (sel.tf === 'W1') {
            const byW = jGroup(L, t => jMonday(jDay(t)).toISOString().slice(0, 10));
            const wks = Object.keys(byW).sort().reverse();
            return React.createElement(React.Fragment, null,
                React.createElement("div", { className: "gj-sec" }, `Minggu dalam bulan ini · ${wks.length} kartu`),
                wks.map(wk => { const W = byW[wk]; const hl = W.some(t => sel.c.ids.includes(t.id)); return React.createElement("div", { className: "week-block", key: wk },
                    React.createElement("div", { className: "week-head" + (hl ? " wk-hl" : "") },
                        React.createElement("div", null, React.createElement("strong", null, jWeekLabel(new Date(wk + 'T00:00:00Z')))),
                        strip(W))); }),
                (() => { const T = L.filter(t => sel.c.ids.includes(t.id)); const byD = jGroup(T, t => jDay(t)); const days = Object.keys(byD).sort().reverse();
                    return React.createElement(React.Fragment, null,
                        days.map(d => { const D = byD[d].sort((a, b) => new Date(b.date) - new Date(a.date)); return React.createElement(React.Fragment, { key: d },
                            React.createElement("div", { className: "date-label" }, React.createElement("span", null, new Date(d + 'T12:00:00').toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })), strip(D)),
                            D.map(tradeCard)); })); })());
        }
        const T = L.filter(t => sel.c.ids.includes(t.id)).sort((a, b) => new Date(b.date) - new Date(a.date));
        return React.createElement(React.Fragment, null,
            React.createElement("div", { className: "date-label" }, React.createElement("span", null, sel.c.label), strip(T)),
            T.map(tradeCard));
    };
    const monthCards = (L0, ym) => { const byM = jGroup(L0, t => jCal(t).slice(0, 7)); return Object.keys(byM).sort().reverse().map(mk => { const L = byM[mk]; const key = 'm' + mk; const def = !!autoOpen && mk === ym; const op = isOpen(key, def); return React.createElement("div", { className: "week-block", key: key },
        head(key, jMonthLabel(mk), L, op, def, false),
        op && React.createElement(React.Fragment, null,
            React.createElement("div", { className: "gj-chart" },
                React.createElement(HeroChart, { trades: withPct(account, L.filter(t => t.status === 'closed')).sort((a, b) => new Date(a.date) - new Date(b.date)), startBal: startBal, tfs: ['H1', 'SES', 'D1', 'W1'], defTf: 'D1', persist: false, hh: 330, fixed: true, onSelect: (c, tf) => setSels(s => ({ ...s, [key]: c ? { c, tf } : null })) })),
            selBlock(key, L))); }); };
    return React.createElement("div", { className: "gj" },
        kind === 'M1' ? monthCards(list, lastMonth) : years.map((y, yi) => { const L = byY[y]; const key = 'y' + y; const def = !!autoOpen && yi === 0; const op = isOpen(key, def); const nM = Object.keys(jGroup(L, t => jCal(t).slice(0, 7))).length; return React.createElement("div", { className: "week-block", key: key },
            head(key, `Tahun ${y}`, L, op, def, true),
            op && React.createElement(React.Fragment, null,
                React.createElement("div", { className: "gj-sec" }, `Bulan dalam tahun ini · ${nM} kartu`),
                monthCards(L, lastMonth))); }));
}
function Journal({ account, trades, filters, setFilters, expanded, setExpanded, onAdd, onScan, onDelete, onClose, onEdit }) {
    const [addMenu, setAddMenu] = useState(false);
    const fileRef = useRef(null);
    const [openWeeks, setOpenWeeks] = useState({});
    const startBal = acctCapBal(account); /* dasar % = modal sekarang */
    const sumOf = list => ({ pnl: list.reduce((x, t) => x + (t.status === 'closed' ? Number(t.pnl) || 0 : 0), 0), pips: list.reduce((x, t) => x + tradePips(t), 0) });
    const filtered = trades.filter(t => (filters.status === 'all' || t.status === filters.status) && (filters.side === 'all' || t.side === filters.side) && (!filters.search || t.symbol.toLowerCase().includes(filters.search.toLowerCase()) || String(t.setup || '').toLowerCase().includes(filters.search.toLowerCase())) && (!filters.date || dateOnly(t.date) === filters.date) && (!filters.ids || filters.ids.includes(t.id)));
    const groups = filtered.reduce((acc, t) => { const key = dateOnly(t.date); (acc[key] || (acc[key] = [])).push(t); return acc; }, {});
    return React.createElement("section", null,
        React.createElement(PageHeading, { eyebrow: "LOGBOOK / TRADE HISTORY", title: "My Journal", description: `Semua transaksi akun ${account.name}.` }),
        React.createElement("div", { className: "journal-controls" },
            React.createElement("div", { className: "search-box" },
                React.createElement(Search, { size: 15 }),
                React.createElement("input", { value: filters.search, onChange: e => setFilters({ ...filters, search: e.target.value }), placeholder: "Cari symbol atau setup..." })),
            React.createElement(TSelect, { title: "Status", value: filters.status, options: [{ v: 'all', l: 'All status' }, { v: 'open', l: 'Open' }, { v: 'closed', l: 'Closed' }], onChange: v => setFilters({ ...filters, status: v }) }),
            React.createElement(TSelect, { title: "Arah", value: filters.side, options: [{ v: 'all', l: 'Long & Short' }, { v: 'Long', l: 'Long' }, { v: 'Short', l: 'Short' }], onChange: v => setFilters({ ...filters, side: v }) }),
            filters.date && React.createElement("button", { className: "filter-chip", onClick: () => setFilters({ ...filters, date: '' }) },
                filters.date,
                " ",
                React.createElement(X, { size: 12 })),
            filters.ids && React.createElement("button", { className: "filter-chip", onClick: () => setFilters({ ...filters, ids: null, idsLabel: '', groupKind: null }) },
                filters.idsLabel || 'Kandel',
                " ",
                React.createElement(X, { size: 12 }))),
        React.createElement("div", { className: "journal-toolbar" },
            React.createElement("button", { className: filters.status === 'all' ? 'pill active' : 'pill', onClick: () => setFilters({ ...filters, status: 'all' }) },
                "All ",
                React.createElement("span", null, trades.length)),
            React.createElement("button", { className: filters.status === 'open' ? 'pill active' : 'pill', onClick: () => setFilters({ ...filters, status: 'open' }) },
                "Open ",
                React.createElement("span", null, trades.filter(t => t.status === 'open').length)),
            React.createElement("button", { className: filters.status === 'closed' ? 'pill active' : 'pill', onClick: () => setFilters({ ...filters, status: 'closed' }) },
                "Closed ",
                React.createElement("span", null, trades.filter(t => t.status === 'closed').length)),
            React.createElement("span", { className: "results-count" },
                React.createElement(Filter, { size: 13 }),
                " ",
                filtered.length,
                " shown")),
        (filters.ids && filters.groupKind) || (!filters.ids && !filters.date) ? React.createElement(HierJournal, { autoOpen: !!filters.ids, key: (filters.groupKind || 'all') + '|' + (filters.idsLabel || ''), kind: filters.groupKind, status: filters.status, list: filtered, account: account, startBal: startBal, expanded: expanded, setExpanded: setExpanded, onDelete: onDelete, onClose: onClose, onEdit: onEdit }) : (() => { const isoOf = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; const weeks = {}; Object.keys(groups).forEach(day => { const d = new Date(`${day}T12:00`); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); const wk = isoOf(d); (weeks[wk] || (weeks[wk] = {}))[day] = groups[day]; }); return Object.keys(weeks).sort().reverse().map((wk, wi) => { const w = weeks[wk]; const list = Object.values(w).flat(); const wsum = sumOf(list), pnl = wsum.pnl; const st = new Date(`${wk}T12:00`); const en = new Date(st); en.setDate(st.getDate() + 6); const open = openWeeks[wk] !== undefined ? openWeeks[wk] : !!(filters.date || filters.ids); const label = `${st.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} - ${en.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}`; return React.createElement("div", { className: "week-block", key: wk },
            React.createElement("button", { className: "week-head", onClick: () => setOpenWeeks({ ...openWeeks, [wk]: !open }) },
                React.createElement("div", null,
                    React.createElement("strong", null, label)),
                React.createElement(ChevronDown, { size: 17, className: open ? 'rotate' : '' }),
                React.createElement(PosStrip, { n: list.length, pnl: pnl, pct: pctChain(account, list), pips: wsum.pips, cur: account.currency })),
            open && Object.keys(w).sort((x, y) => y.localeCompare(x)).map(day => { const dsum = sumOf(w[day]), dp = dsum.pnl; return React.createElement("div", { key: day },
                React.createElement("div", { className: "date-label" },
                    React.createElement("span", null, new Date(`${day}T12:00`).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })),
                    React.createElement(PosStrip, { n: w[day].length, pnl: dp, pct: pctChain(account, w[day]), pips: dsum.pips, cur: account.currency })),
                w[day].map(t => React.createElement(TradeCard, { key: t.id, trade: t, startBal: acctCapAt(account, t.date), expanded: expanded === t.id, onToggle: () => setExpanded(expanded === t.id ? null : t.id), onDelete: () => onDelete(t.id), onClose: () => onClose(t), onEdit: () => onEdit(t) }))); })); }); })(),
        !filtered.length && React.createElement("div", { className: "empty-state" },
            React.createElement(BookOpen, { size: 26 }),
            React.createElement("strong", null, "Tidak ada trade yang cocok"),
            React.createElement("span", null, "Ubah filter atau tambah transaksi baru.")),
        addMenu && React.createElement(AddMenu, { onClose: () => setAddMenu(false), onManual: () => { setAddMenu(false); onAdd(); }, onScreenshot: () => { setAddMenu(false); if (fileRef.current) { fileRef.current.value = ''; fileRef.current.click(); } } }),
        React.createElement("input", { ref: fileRef, type: "file", accept: "image/*", multiple: true, style: { display: 'none' }, onChange: e => { const f = e.target.files ? [...e.target.files] : []; if (f.length && onScan) onScan(f); } }),
        React.createElement("button", { className: addMenu ? "fab open" : "fab", "aria-label": "Tambah trade", "aria-expanded": addMenu, onClick: () => setAddMenu(!addMenu) },
            React.createElement(Plus, { size: 25 })));
}
function TradeCard({ trade, startBal, expanded, onToggle, onDelete, onClose, onEdit }) { var _a, _b, _c, _d; return React.createElement("div", { className: "trade-card", onClick: onToggle },
    React.createElement("div", { className: "trade-main" },
        React.createElement("div", { className: `side-dot ${trade.status === 'open' ? 'blue' : trade.pnl >= 0 ? 'green' : 'red'}` }),
        React.createElement("div", { className: "trade-info" },
            React.createElement("div", null,
                React.createElement("strong", null, trade.symbol),
                React.createElement("span", { className: trade.side === 'Long' ? 'side long' : 'side short' }, trade.side),
                React.createElement("span", { className: trade.status === 'open' ? 'side open' : 'side closed' }, trade.status === 'open' ? 'OPEN' : trade.exitMethod || 'CLOSED')),
            React.createElement("small", null,
                new Date(trade.date).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }).replace(/\./g, ':'),
                " \u00B7 ",
                trade.setup || 'Tanpa setup')),
        React.createElement("div", { className: "trade-result" },
            trade.status === 'open' ? React.createElement(React.Fragment, null,
                React.createElement("strong", { className: "open-text" }, "OPEN"),
                React.createElement("small", null, "ACTIVE")) : React.createElement(React.Fragment, null,
                React.createElement("strong", { className: trade.pnl >= 0 ? 'positive' : 'negative' },
                    trade.pnl >= 0 ? '+' : '',
                    money(trade.pnl)),
                React.createElement("small", { className: `tr-sub ${trade.pnl >= 0 ? 'positive' : 'negative'}` }, fmtPctS((Number(trade.pnl) || 0) / (startBal || 1) * 100) + ' \u00B7 ' + fmtPipsS(pipsOf(trade)))),
            " "),
        React.createElement(ChevronDown, { size: 17, className: expanded ? 'rotate' : '' })),
    expanded && React.createElement("div", { className: "trade-detail" },
        React.createElement("div", null,
            React.createElement("span", null, "Entry / Exit"),
            React.createElement("b", null,
                trade.entry,
                " \u2192 ", (_a = trade.exit) !== null && _a !== void 0 ? _a : '—')),
        React.createElement("div", null,
            React.createElement("span", null, "Hasil"),
            React.createElement("b", { className: trade.status === 'open' ? '' : trade.pnl >= 0 ? 'positive' : 'negative' }, trade.status === 'open' ? 'OPEN' : (trade.pnl >= 0 ? 'WIN' : 'LOSS') + ' \u00B7 ' + fmtPctS((Number(trade.pnl) || 0) / (startBal || 1) * 100) + ' \u00B7 ' + fmtPipsS(pipsOf(trade)))),
        React.createElement("div", null,
            React.createElement("span", null, "Lots"),
            React.createElement("b", null, trade.lots)),
        React.createElement("div", null,
            React.createElement("span", null, "SL / TP"),
            React.createElement("b", null, (_b = trade.sl) !== null && _b !== void 0 ? _b : '—',
                " / ", (_c = trade.tp) !== null && _c !== void 0 ? _c : '—')),
        React.createElement("div", null,
            React.createElement("span", null, "Fees / Net P&L"),
            React.createElement("b", null,
                money(trade.fees || 0),
                " / ",
                money(trade.pnl))),
        React.createElement("div", null,
            React.createElement("span", null, "Review"),
            React.createElement("b", null, trade.review || 'Belum ada review')),
        trade.closeDate && React.createElement("div", null,
            React.createElement("span", null, "Closed at"),
            React.createElement("b", null, new Date(trade.closeDate).toLocaleString('id-ID').replace(/\./g, ':'))),
        ((_d = trade.screenshots) === null || _d === void 0 ? void 0 : _d.length) > 0 && React.createElement("div", { className: "screenshot-strip" }, trade.screenshots.map((src, i) => React.createElement("img", { key: i, src: src, alt: `Chart ${i + 1}` }))),
        trade.status === 'open' && React.createElement("button", { className: "secondary-btn detail-action", onClick: e => { e.stopPropagation(); onClose(); } }, "Tutup posisi"),
        React.createElement("div", { className: "trade-actions" },
            React.createElement("button", { className: "edit-btn", onClick: e => { e.stopPropagation(); onEdit(); } }, "\u270E Edit"),
            React.createElement("button", { className: "delete-btn", onClick: e => { e.stopPropagation(); onDelete(); } },
                React.createElement(Trash2, { size: 14 }),
                " Hapus")))); }
